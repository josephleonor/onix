
{
    "name": "Ventas a Crédito con Pagaré Notarial",
    "version": "1.0",
    "depends": ["account", "base"],
    "author": "Desarrollo personalizado",
    "category": "Accounting",
    "description": "Módulo para gestión de ventas a crédito, pagarés notariales y cuotas en Odoo 17 Community.",
    "data": [
        "security/ir.model.access.csv",
        "views/account_move_views.xml",
        "views/pagare_views.xml",
        "report/pagare_report.xml",
        "report/pagare_report_template.xml"
    ],
    "installable": True,
    "application": True,
}
